import random

reshte = raw_input("Number Pass:   ");reshte = int(reshte)

print ''.join([random.choice
                (
                    'abcdefghijklmnopqrstuvwxyz'
                    +
                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                    +
                    '!@#$%^&*()_+,><;./?`'
                    +
                    '1234567890'
                )
                for i in range(reshte)])
