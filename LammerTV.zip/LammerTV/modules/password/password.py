import os
os.system("clear")
os.system("figlet Password | lolcat")
print'''


\033[1;32m
                 Create By AmirCyber01
====================================================
[+]  Team       : LammerTV
[+]  Programmer : AmirCyber01 :)           
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================      
\033[1;91m
     
'''
print'''
       [1] Secure Password
       ==============================
       [2] Password list Generator
       ==============================
       [99] Back


'''
x = input("LammerTV=>  ")

if x == 1:
   os.system("python2 modules/password/passs.py")
if x == 2:
   os.system("python3 modules/password/passlist.py")
if x == 99:
   os.system("python2 LammerTV.py")
