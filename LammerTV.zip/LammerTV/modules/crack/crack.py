import os
os.system("clear")
os.system("figlet Cracking | lolcat")
print'''
\033[1;94m
                Create By AmirCyber01
====================================================
[+]  Team       : LammerTV                       
[+]  Programmer : AmirCyber01 ;)         
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================
\033[1;m
\033[1;92m    
        [1] Gmail Cracker
        ===============================
        [2] Instagram User Lecher
        ===============================
        [3] Router Admin Panel Bruteforce
        ===============================
        [4] IP Changer (Proxy)
        ===============================
        [5] FTP Brute Force
        ===============================
        [99] Back
\033[1;m


'''

x = input("LammerTV=>  ")

if x == 1:
   os.system("python2 modules/crack/gmail.py")
if x == 99:
   os.system("python2 LammerTV.py")
if x == 2:
   os.system("python3 modules/crack/lecher.py")
if x == 3:
   os.system("python2 modules/crack/ruter.py")
if x == 4:
   os.system("python3 modules/crack/proxy.py")
if x == 5:
   os.system("python3 modules/crack/ftps.py")
