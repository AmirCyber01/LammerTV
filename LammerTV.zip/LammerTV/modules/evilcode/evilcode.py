import os
os.system("clear")
os.system("clear")
os.system("figlet Evil Codes | lolcat")

print'''
\033[1;93m
                Create By AmirCyber01
====================================================
[+]  Team       : LammerTV                       
[+]  Programmer : AmirCyber01 ;)         
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================
\033[1;m
\033[1;94m    
     
    [1] Cpu Overloader
    =====================
    [2] Delete Root
    =====================
    [99] Back



'''

x = input("LammerTV=>  ")

if x == 1:
   os.system("cp modules/evilcode/cpu.py $HOME")
   print ("save in home")
if x == 2:
   os.system("cp modules/evilcode/root.py $HOME")
   print ("save in home")
if x == 99:
   os.system("python2 LammerTV.py")
