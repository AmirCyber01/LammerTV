import os
os.system("clear")
os.system("figlet Web Tools | lolcat")

print'''

\033[1;32m
                Create By AmirCyber01
==================================================== 
[+]  Team       : LammerTV                       
[+]  Programmer : AmirCyber01 ;)         
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================      
\033[1;91m


      [1] SQL Dorks
      =================
      [2] XSS Dorks
      =================
      [99] Exit



'''
x = input("LammerTV=>  ")

if x == 1:
   os.system("cat modules/webtools/sql.txt")
if x == 99:
   os.system("python2 LammerTV.py")
if x == 2:
   os.system("cat modules/webtools/xss.txt")













